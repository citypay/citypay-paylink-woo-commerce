(function($){
	"use strict";

	var PGL_Parallax = function(){
		if(!Modernizr.touch){ 
		    jQuery.stellar();
		}
    }

    var PGL_FixIsotope = function(){
    	"use strict";
    	if(jQuery().isotope){
			jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				jQuery('.isotope').isotope('reLayout');
			});
			jQuery('[id*="accordion-"]').on('shown.bs.collapse',function(e){
				jQuery('.isotope').isotope('reLayout');
			});
		}
    }

    var PGL_Carousel = function(){
		var owl = $('[data-owl="slide"]');
		var $item = owl.data('item-slide');
		owl.owlCarousel({
			navigation : false,
			pagination: true,
			items : $item,
			itemsCustom : false,
			itemsDesktop : [1199,4],
			itemsDesktopSmall : [991,3],
			itemsTablet: [768,2],
			itemsTabletSmall: [640,2],
			itemsMobile : [480,1],
			singleItem : false,
			itemsScaleUp : false,
			navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]
			
		});
		
		// Custom Navigation Events
		$("#owl-product-slide .next").click(function(){
			owl.trigger('owl.next');
		})
		
		$("#owl-product-slide .prev").click(function(){
			owl.trigger('owl.prev');
		})
    }
    
    var PGL_Menu_Search_Form = function(){
    	var $search_menu = $("#menu-search-form");
    	$('.search-toggle').click(function(){
    		$search_menu.addClass('active');
    	});
    	$search_menu.find('.search-close').click(function(){
    		$search_menu.removeClass('active');
    	});
    }

    var PGL_Button_Back_Top = function(){
    	var _isScrolling = false;
    	$("#scrollToTop").click(function(e) {
			e.preventDefault();
			$("body, html").animate({scrollTop : 0}, 500);
			return false;
		});

		// Show/Hide Button on Window Scroll event.
		$(window).scroll(function() {
			if(!_isScrolling) {
				_isScrolling = true;
				if($(window).scrollTop() > 150) {
					$("#scrollToTop").stop(true, true).addClass("visible");
					_isScrolling = false;
				} else {
					$("#scrollToTop").stop(true, true).removeClass("visible");
					_isScrolling = false;
				}
			}
		});
    }

    var PGL_Header_Sticky = function(){
    	
    }

    var PGL_Language_Topbar = function(){
    	// Set current language to top bar item
		var currentLanguage = $('#header-languages  li.active span').text();
		if (currentLanguage !== "") {
			$('#header-languages').prev().html(currentLanguage );
		}
    }

	$(document).ready(function() {
		PGL_Header_Sticky();
		PGL_Carousel();
		PGL_Button_Back_Top();
		PGL_Parallax();
		PGL_FixIsotope();
		PGL_Menu_Search_Form();
		PGL_Language_Topbar();
		// init Animate Scroll
        if( $('body').hasClass('pgl-animate-scroll') && !Modernizr.touch ){
            new WOW().init();
        }

	});

	$(window).resize(function(){

	});

    $(window).load(function(){

    });

})(jQuery);
