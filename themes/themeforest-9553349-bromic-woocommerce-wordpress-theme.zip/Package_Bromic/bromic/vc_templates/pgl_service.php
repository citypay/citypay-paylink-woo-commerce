<?php 
extract(shortcode_atts(array(
    'title' => '',
    'desc' => '',
    'icon' => '',
    'link_title' => ''
), $atts));
$start_link = $end_link = '';
if($link_title!=''){
	$start_link = '<a href="'.esc_url($link_title).'">';
	$end_link = '</a>';
}
?>
<div class="pgl-service">
    <div class="service-icon">
    	<i class="fa <?php echo esc_attr($icon); ?>"></i>
    </div>
    <div class="service-name"><?php echo $start_link.$title.$end_link; ?></div>
    <div class="service-text"><?php echo $desc; ?></div>
</div>