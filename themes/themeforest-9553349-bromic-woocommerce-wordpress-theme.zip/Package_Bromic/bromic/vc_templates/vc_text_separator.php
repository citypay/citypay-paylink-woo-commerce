<?php
$output = $title = $title_align = $el_class = '';
extract(shortcode_atts(array(
    'title' => __("Title", "js_composer"),
    'title_align' => 'separator_align_center',
    'el_class' => '',
    'descript' => '',
), $atts));
$el_class = $this->getExtraClass($el_class);

?>

<h3 class="widget-title text-center"><span><?php echo $title; ?></span></h3>
<?php if(trim($descript)!=''){ ?>
	<div class="descript descript-title">
		<?php echo $descript; ?>
	</div>
<?php } ?>

