!function ($) {
	"use strict";
	$(document).ready(function() {
		$('.quickview').click(function(){
        	var proid = $(this).data('proid');
   			var data = { action: 'pgl_quickview', product: proid};
   			var loading = $(this).prev();
   			loading.show();
   			$.post(ajaxurl, data, function(response) {
   				$.magnificPopup.open({
					items: {
						src: '<div class="product-quickview">'+response+'</div>', // can be a HTML string, jQuery object, or CSS selector
						type: 'inline'
					}
				});
				$('.quickview-slides').owlCarousel({
					navigation : false,
					pagination: true,
					items :1,
				});
				loading.hide();
   			});
			return false;
        });

		// Ajax Remove Cart
		$(document).on('click', '.pgl_product_remove', function(event) {
			var $this = $(this);
			var product_key = $this.data('product-key');
			var product_id = $this.data('product-id');
	        $.ajax({
	            type: 'POST',
	            dataType: 'json',
	            url: ajaxurl,
	            data: { action: "cart_remove_product", 
                    product_key: product_key,
                    product_id : product_id
	            },success: function(data){
	                $cart = $('.shopping-cart');
	                $cart.find('.amount').remove();
	                $cart.find('>li>a').append(data.subtotal);
	                var $cart = $('#pgl_cart_canvas');
	                if(data.count==0){
	                	$cart.find('.cart_list').html('<li class="empty">'+$cart.find('.cart_container').data('text-emptycart')+'</li>');
	                	$cart.find('.total,.buttons').remove();
	                }else{
		                $cart.find('.total .amount').remove();
		                $cart.find('.total').append(data.subtotal);
		                $this.parent().remove();
	                }
	            }
	        });
	        return false;
		});
		$('.pgl_product_remove').click(function(){
			
		});

		$('body').delegate('.button-item .btn-wishlist', 'click', function(event) {
			var $button = $(this).next();
			$button.find('.add_to_wishlist').trigger('click');
			return false;
		});

		$('body').delegate('.button-item .btn-compare', 'click', function(event) {
			var $button = $(this).next().trigger('click');
			return false;
		});

		// Single Product
		$('body').delegate('.cart-inner .btn-wishlist', 'click', function(event) {
			$('#single-product .add_to_wishlist').trigger('click');
			return false;
		});

		$('body').delegate('.cart-inner .btn-compare', 'click', function(event) {
			$('#single-product .compare.button').trigger('click');
			return false;
		});

	});
}(jQuery);