<?php

global $theme_option;
?>
        	<footer id="pgl-footer" class="pgl-footer">
                <div class="footer-content container">
                    <?php 
                       do_action( 'pgl_footer_layout_style' );
                    ?>
                </div>
                <div class="footer-bottom">
                    <div class="inner container">
                       <?php echo do_shortcode( $theme_option['copyright_text'] ); ?>
                    </div>
                </div>
        	</footer>
        </div><!--  End .wrapper-inner -->
    </div><!--  End .pgl-wrapper -->
    
    <?php do_action('pgl_after_wrapper'); ?>

	<?php wp_footer(); ?>
</body>
</html>