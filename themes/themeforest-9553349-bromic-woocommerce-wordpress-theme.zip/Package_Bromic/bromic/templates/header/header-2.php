<?php 
    global $theme_option;
    $login_url = wp_login_url();
    $logout_url = wp_logout_url( home_url() );
    $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
    if ( $myaccount_page_id ) {
        $logout_url = wp_logout_url( get_permalink( $myaccount_page_id ) );
        $login_url = get_permalink( $myaccount_page_id );
        if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'yes' ) {
            $logout_url = str_replace( 'http:', 'https:', $logout_url );
            $login_url = str_replace( 'http:', 'https:', $login_url );
        }
    }
?>
<header id="pgl-header" class="pgl-header header-style2">
    <div id="header-topbar">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-xs-12 inner">
                    <ul class="swicher-action nav navbar-nav">
		                <?php if($theme_option['header-is-switch-language']==true){ ?>
		                <li class="dropdown">
		                    <a href="#" data-toggle="dropdown" class="language name">English</a>
		                    <ul id="header-languages" class="sub-menu dropdown-menu">
		                        <li><a href="#"><span class="language name">German</span></a></li>
		                        <li class="active"><a href="#"><span class="language name">English</span></a></li>
		                        <li><a href="#"><span class="language name">Spanish</span></a></li>
		                        <li><a href="#"><span class="language name">French</span></a></li>
		                    </ul>
		                </li>
		                <?php } ?>
		                <?php
		                if($theme_option['header-is-login']==true){
		                    if (is_user_logged_in()) {
		                        echo '<li class="dropdown"><a href="'.wp_logout_url(home_url()).'">'. __("Sign Out", "flatize") .'</a></li>'. "\n";
		                        if ( $myaccount_page_id ) {
		                            echo '<li class="dropdown"><a href="'.get_permalink( $myaccount_page_id ).'" class="admin-link">'. __("My Account", "flatize") .'</a></li>'. "\n";
		                        } else {
		                            echo '<li class="dropdown"><a href="'.get_admin_url().'" class="admin-link">'. __("My Account", "flatize") .'</a>'. "\n";
		                        }
		                    } else {
		                        echo '<li class="dropdown"><a href="'.$login_url.'">'. __("Login", "flatize") .'</a>'. "\n";          
		                    }
		                }
		                ?>
		            </ul>
                </div>
                <div class="col-sm-6 hidden-xs inner">
                    <?php echo do_shortcode( '[pgl_social]' ); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="header-content container">
        <div class="logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <img src="<?php echo esc_url($theme_option['logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
            </a>
        </div>
        <?php if( $theme_option['header-is-login']==true){ ?>
        <div class="logo-action">
            <?php if($theme_option['header-is-cart']){ ?>
            <ul class="shopping-cart nav navbar-nav">
                <li class="dropdown">
                    <?php global $woocommerce; ?>
                    <a href="javascript:;" data-uk-offcanvas="{target:'#pgl_cart_canvas'}">
                        <i class="fa fa-shopping-cart"></i> <?php echo $woocommerce->cart->get_cart_total(); ?>
                    </a>
                </li>
            </ul>
            <?php } ?>
        </div>
        <?php } ?>
    </div>

    <div class="header-mainmenu">
        <div class="container">
            <?php pgl_megamenu(array(
                    'theme_location' => 'mainmenu',
                    'container_class' => 'collapse navbar-collapse container navbar-ex1-collapse',
                    'menu_class' => 'nav navbar-nav megamenu',
            )); ?>
            <div class="menu-right inner">
                <?php if($theme_option['header-is-search']==true){ ?>
                <a href="javascript:;" class="search-toggle icon-toggle">
                    <i class="fa fa-search"></i>
                </a>
                <?php } ?>
                <a href="javascript:;" class="off-canvas-toggle icon-toggle" data-uk-offcanvas="{target:'#pgl-off-canvas'}">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
            </div>
            <?php if($theme_option['header-is-search']==true){ ?>
            <div class="menu-serch-form col-xs-12" id="menu-search-form">
                <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
                    <div class="search-box" id="searchBox">
                        <input type="text" class="search-input" id="searchInput" name="s" placeholder="Start typing...">
                        <button type="submit" class="hidden">Search</button>
                        <a href="javascript:" class="fa search-close" data-toggle-active="#menu-search-form">&times;</a>
                    </div>
                </form>
            </div>
            <?php } ?>
        </div>
    </div>
</header>