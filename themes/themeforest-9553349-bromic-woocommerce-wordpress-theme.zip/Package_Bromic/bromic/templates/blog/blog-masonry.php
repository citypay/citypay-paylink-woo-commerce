
<article id="post-<?php the_ID(); ?>" <?php post_class('blog-masonry col-sm-'.(12/apply_filters( 'pgl_blog_masonry_column', 3 )) ); ?>>
	<div class="blog-container">
		<?php do_action('pgl_post_before_content'); ?>
		<div class="blog-container-inner text-center">
			<h2 class="blog-title">
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h2>

			<div class="blog-content">
				<?php echo pgl_get_excerpt(10,'...'); ?>
			</div>
			
			<?php get_template_part( 'templates/single/meta' ); ?>
		</div>
	</div>
</article>