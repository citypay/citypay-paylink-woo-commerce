
<article id="post-<?php the_ID(); ?>" <?php post_class('blog-container clearfix'); ?>>
	<?php do_action('pgl_post_before_content'); ?>
	<div class="blog-container-inner">
		<h2 class="blog-title">
			<a href="<?php the_permalink(); ?>">
				<?php the_title(); ?>
			</a>
		</h2>

		<div class="blog-content">
			<?php echo pgl_get_excerpt(120); ?>
			<a href="<?php the_permalink(); ?>" class="btn btn-transparent btn-sm"><?php echo __( 'Read More','bromic' ); ?></a>
		</div>
		
		<?php get_template_part( 'templates/single/meta' ); ?>
	</div>
</article>