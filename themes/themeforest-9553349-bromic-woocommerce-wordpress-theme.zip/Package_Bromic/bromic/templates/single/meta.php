<div class="blog-meta clearfix">
	<ul>
		<li class="author-link"><i class="fa fa-user"></i> <?php the_author_posts_link(); ?></li>
		<li class="author-link"><i class="fa fa-eye"></i> <?php echo pgl_get_post_views(get_the_ID()); ?></li>
		<li class="author-link"><i class="fa fa-calendar"></i> <?php the_time( 'M d, Y' ); ?></li>
		<li>
			<i class="fa fa-comment-o"></i>
			<?php comments_popup_link(__(' 0 comment', 'bromic'), __(' 1 comment', 'bromic'), __(' % comments', 'bromic')); ?>
		</li>
	</ul>
</div>