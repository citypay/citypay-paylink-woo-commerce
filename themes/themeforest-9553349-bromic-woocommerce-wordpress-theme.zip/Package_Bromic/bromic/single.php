
<?php pgl_get_header( ); ?>

<?php get_template_part( 'templates/breadcrumb' ); ?>

<div id="pgl-mainbody" class="pgl-mainbody">
	<!-- MAIN CONTENT -->
	<div id="pgl-content" class="pgl-content">
		<?php while ( have_posts() ) : the_post(); global $post; ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('single-container'); ?>>
				<div class="container">
					<?php do_action('pgl_post_before_content'); ?>
					<div class="post-content">
						<?php the_content(); ?>
						<?php wp_link_pages(); ?>
					</div>
				</div>

				<div class="post-meta">
					<div class="container">
						<div class="row">
							<div class="col-sm-4 inner-table">
								<?php get_template_part( 'templates/single/author-bio' ); ?>
							</div>
							<div class="col-sm-4 inner-table">
								<?php get_template_part( 'templates/single/meta'  ); ?>
							</div>
							<div class="col-sm-4 inner-table post-share">
								<?php get_template_part( 'templates/sharebox' ); ?>
							</div>
						</div>
					</div>
				</div>

				<?php get_template_part( 'templates/single/related' ); ?>

				<?php comments_template(); ?>
			</article>
		<?php endwhile; ?>
	</div>
	<!-- //MAIN CONTENT -->
</div>

<?php get_footer(); ?>

