<?php

global $theme_option;
//return;
$main_color = $theme_option['style_main_color'];
if($main_color=='custom'){
  $main_color = $theme_option['style_main_custom'];
}

$color_hover = pgl_adjustColorLightenDarken( $main_color,20 );

?>
a,.shoppingcart .media .pgl_product_remove:hover .fa,.shoppingcart p.total .amount,.shoppingcart .name a:hover,.woocommerce-breadcrumb a:hover,#breadcrumbs a:hover,.post-container .entry-title a:hover,.pgl-sidebar ul li a:hover,.pgl-footer a:hover,.pgl-footer address a:hover,.pgl-footer .tw-widget a,.pgl_search:hover .fa,.grid-posts .title a:hover ,.related-post-content a:hover, .blog-meta .meta-comment a:hover,.blog-meta a:hover,.commentlists .the-comment .comment-box .comment-action a:hover ,.item-product-widget .product-meta .title a:hover,.item-product-widget .product-meta .category a:hover,.product-block.product-list .woocommerce-review-link:hover,.product-block .name a:hover,.woocommerce table.shop_table td a:hover,.woocommerce .price ins,.woocommerce .price ins span ,#single-product div.summary .woocommerce-review-link:hover,.shop_table .order-total .amount,.uk-nav-offcanvas > .uk-open > a,html:not(.uk-touch) .uk-nav-offcanvas > li > a:hover,html:not(.uk-touch) .uk-nav-offcanvas > li > a:focus,html:not(.uk-touch) .uk-nav-offcanvas ul a:hover,.uk-active > a,#pgl-mainnav .megamenu > li:hover > a ,#pgl-mainnav .megamenu > li .current-menu-item > a > span,#pgl-mainnav .megamenu .woocommerce .product-meta .title a:hover,#pgl-mainnav .mega-col-nav .mega-inner ul li a:focus,#pgl-mainnav .mega-col-nav .mega-inner ul li a:hover,#pgl-mainnav .mega-col-nav .mega-inner ul li.active a,.text-primary,.btn-primary .badge,.btn-link,a.list-group-item.active > .badge,.nav-pills > .active > a > .badge,.panel-heading a:hover,.product-block .button-item a.button:hover,.swicher-action a:hover,#pgl-header.header-style2 #header-topbar .social-networks li a:hover,.header-content .logo-action .shopping-cart > li > a:hover,.pgl-megamenu .megamenu a:hover,.pgl-megamenu .megamenu span:hover,.icon-toggle:hover,.pgl-sidebar ul.product-categories li:hover > a,.blog-meta ul .fa,.widget .comment-author-link a,.blog-container .blog-title a:hover,.author-about-container a:hover{
  color: <?php echo $main_color; ?>;
}
.uk-active > a,.pgl-megamenu .megamenu li.current-menu-item > a span,.pgl-megamenu .megamenu li.current-menu-parent > a span,.pgl-megamenu .megamenu li.current-menu-ancestor > a span,.post-grid .entry-title a:hover{
  color: <?php echo $main_color; ?>!important;
}

.shoppingcart .badge,.scroll-to-top,.nav-tabs.tab-widget li.active a,.pgl-sidebar .widget_product_categories .widget-inner,.pgl-sidebar .widget_categories .widget-inner,.pgl-sidebar .widget_calendar caption,#pgl-mainbody .tparrows:hover,.post-thumb a.post-img-1:hover,.blog-meta .meta-date > span,.shoppingcart .badge ,.product-block .image .onsale,.product-block.product-list .button-item a.btn-cart,#single-product .cart-inner .button.btn-cart,.woocommerce-page #respond input#submit ,.woocommerce-page a.button.alt,.woocommerce-page input.button.alt,.woocommerce-page a.button,.woocommerce-page button.button,.product-quickview .woocommerce .btn-cart:hover,#pgl-mainnav .megamenu > li > a > span:after,.btn-primary,.btn-primary.disabled,.btn-primary[disabled],fieldset[disabled] .btn-primary,.btn-primary.disabled:hover,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary:hover,.btn-primary.disabled:focus,.btn-primary[disabled]:focus,fieldset[disabled] .btn-primary:focus,.btn-primary.disabled:active,.btn-primary[disabled]:active,fieldset[disabled] .btn-primary:active,.btn-primary.disabled.active,.btn-primary[disabled].active,fieldset[disabled] .btn-primary.active,.nav-pills > li.active > a,.nav-pills > li.active > a:hover,.nav-pills > li.active > a:focus,.pagination > li > span.current,.pagination > .active > a,.pagination > .active > span,.pagination > .active > a:hover,.pagination > .active > span:hover,.pagination > .active > a:focus,.pagination > .active > span:focus,.pagination > li > a:hover,.pagination > li > span:hover,.pagination > li > a:focus,.pagination > li > span:focus,.pagination > li > span.current
.label-primary,.progress-bar,.list-group-item.active,.list-group-item.active:hover,.list-group-item.active:focus,.panel-primary > .panel-heading,.product-block .image .pgl_added_to_cart,.pgl-service .service-icon,#pgl-header.header-style2 .header-mainmenu,.post-widget .date-circle,#pgl-header.header-style2 .menu-serch-form,.woocommerce-tabs .nav-tabs li.active a,.pgl-megamenu .megamenu > li > a:before,.dropdown-menu > .active > a,.dropdown-menu > .active > a:hover,.dropdown-menu > .active > a:focus,.dropdown-menu > li > a:hover,.dropdown-menu > li > a:focus,.post-share .social-networks li:hover
{
  background: <?php echo $main_color; ?>;
}

.nav-tabs.tab-widget li.active a:after,.pgl-count-down,.nav .caret,.panel-primary > .panel-heading + .panel-collapse .panel-body {
  border-top-color: <?php echo $main_color; ?>;
}
.nav .caret,.panel-primary > .panel-footer + .panel-collapse .panel-body{
  border-bottom-color: <?php echo $main_color; ?>;
}

.pgl-footer .widget .tagcloud a:hover ,.product-quickview .woocommerce .btn-cart:hover,.btn-primary,.btn-primary.disabled,.btn-primary[disabled],fieldset[disabled] .btn-primary,.btn-primary.disabled:hover,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary:hover,.btn-primary.disabled:focus,.btn-primary[disabled]:focus,fieldset[disabled] .btn-primary:focus,.btn-primary.disabled:active,.btn-primary[disabled]:active,fieldset[disabled] .btn-primary:active,.btn-primary.disabled.active,.btn-primary[disabled].active,fieldset[disabled] .btn-primary.active,.pagination > li > span.current,.pagination > .active > a,.pagination > .active > span,.pagination > .active > a:hover,.pagination > .active > span:hover,.pagination > .active > a:focus,.pagination > .active > span:focus,a.thumbnail:hover,a.thumbnail:focus,.list-group-item.active,.list-group-item.active:hover,.list-group-item.active:focus,.panel-primary,.panel-primary > .panel-heading
{
  border-color: <?php echo $main_color; ?>;
}

.woocommerce-tabs .nav-tabs > li.active a{
  border-right-color: <?php echo $main_color; ?>;
}

/* Hover */
a:hover,.btn-link:hover,.btn-link:focus{
  color: <?php echo $color_hover; ?>;
}

.btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.open > .dropdown-toggle.btn-primary,.label-primary[href]:hover,.label-primary[href]:focus
{
  background: <?php echo $color_hover; ?>;
}

.btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.open > .dropdown-toggle.btn-primary{
  border-color: <?php echo $color_hover; ?>;
}

.nav a:hover .caret{
  border-top-color:<?php echo $color_hover; ?>;
}

.nav a:hover .caret{
  border-bottom-color:<?php echo $color_hover; ?>;
}