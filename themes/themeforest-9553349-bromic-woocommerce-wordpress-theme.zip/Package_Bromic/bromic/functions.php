<?php

define( 'PGL_THEME_PATH', get_template_directory() );
define( 'PGL_THEME_VERSION', '1.1' );

require( PGL_THEME_PATH . '/framework/init.php');

