<div class="inline error">
    <p>
        <strong><?php esc_html_e('Gateway Disabled', 'woocommerce'); ?></strong>:
        <?php esc_html_e(sprintf('Requires WooCommerce %s or later', $this->min_wc_ver), 'woocommerce'); ?>
    </p>
</div>